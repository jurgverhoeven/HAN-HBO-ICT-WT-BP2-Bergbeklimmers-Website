<footer>
    <p>&copy; Jurg Verhoeven, Juriaan Pijls, Umied Alakbarov</p>
</footer>
</body>
</html>